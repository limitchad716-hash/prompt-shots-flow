package com.promptshots.flow

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

class FlowAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: FlowAccessibilityService? = null
        private val STRONG = Regex("generate|arrow_forward|send|submit")
        private val WEAK = Regex("create|run")
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun roots(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        for (w in windows) {
            if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val r = w.root ?: continue
            if (r.packageName?.toString() != packageName) out.add(r)
        }
        if (out.isEmpty()) rootInActiveWindow?.let { if (it.packageName?.toString() != packageName) out.add(it) }
        return out
    }

    private fun walk(root: AccessibilityNodeInfo, visit: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        while (q.isNotEmpty()) {
            val n = q.removeFirst()
            if (visit(n)) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return null
    }

    private fun findField(): AccessibilityNodeInfo? {
        val rs = roots()
        for (r in rs) walk(r) { it.isEditable && it.isFocused }?.let { return it }
        for (r in rs) walk(r) { it.isEditable && it.isVisibleToUser }?.let { return it }
        return null
    }

    private fun label(n: AccessibilityNodeInfo) =
        ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()

    private fun findButton(): AccessibilityNodeInfo? {
        val rs = roots()
        for (re in listOf(STRONG, WEAK)) {
            for (r in rs) walk(r) { it.isVisibleToUser && it.isEnabled && re.containsMatchIn(label(it)) }?.let { return it }
        }
        return null
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    /** Types the prompt into Flow's prompt box, then taps Generate. */
    fun pasteAndRun(text: String, done: (String) -> Unit) {
        val field = findField()
        if (field == null) { done("Can't find the prompt box. Open Google Flow first."); return }
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            done("Couldn't type into the prompt box."); return
        }
        Handler(Looper.getMainLooper()).postDelayed({
            val b = findButton()
            if (b == null) done("Pasted. Can't find Generate, tap it yourself.")
            else if (click(b)) done("Sent") else done("Pasted. Tap Generate yourself.")
        }, 900)
    }
}
