package com.promptshots.flow

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

const val SITE = "https://celebrated-taiyaki-a19087.netlify.app"

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("flow", Context.MODE_PRIVATE)
    fun delay(c: Context) = sp(c).getInt("delay", 60)
    fun setDelay(c: Context, v: Int) = sp(c).edit().putInt("delay", v).apply()
    fun prompts(c: Context) = sp(c).getString("prompts", "") ?: ""
    fun setPrompts(c: Context, v: String) = sp(c).edit().putString("prompts", v).apply()
}

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val pad = (8 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF12151C.toInt())
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { setTextColor(0xFFE9EDF3.toInt()); textSize = 11f }
        val bFloat = Button(this).apply { text = "Float"; setOnClickListener { startFloating() } }
        val bSet = Button(this).apply { text = "Settings"; setOnClickListener { showSettings() } }
        bar.addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(bFloat)
        bar.addView(bSet)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl(SITE)
        }
        root.addView(bar)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun hasOverlay() = Settings.canDrawOverlays(this)
    private fun hasNotif() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    private fun hasAcc() = FlowAccessibilityService.instance != null

    private fun refreshStatus() {
        fun s(v: Boolean) = if (v) "OK" else "OFF"
        status.text = "Window: ${s(hasOverlay())}  Auto-run: ${s(hasAcc())}  Notif: ${s(hasNotif())}"
    }

    private fun startFloating() {
        if (!hasOverlay()) { toast("Allow 'Display over other apps' first"); openOverlaySettings(); return }
        if (!hasNotif()) { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
        val i = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        if (!hasAcc()) toast("Tip: turn on Accessibility in Settings so Run can paste for you")
    }

    private fun openOverlaySettings() =
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    private fun showSettings() {
        val items = arrayOf(
            "1. Floating window permission",
            "2. Accessibility (auto paste & run)",
            "3. Notifications",
            "4. Allow restricted settings (App info)",
            "5. Battery: do not restrict",
            "6. Wait between prompts: ${Prefs.delay(this)} s"
        )
        AlertDialog.Builder(this).setTitle("Settings").setItems(items) { _, w ->
            when (w) {
                0 -> openOverlaySettings()
                1 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                2 -> if (Build.VERSION.SDK_INT >= 33 && !hasNotif()) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                } else {
                    startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
                }
                3 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                4 -> startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                5 -> askDelay()
            }
        }.show()
    }

    private fun askDelay() {
        val e = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.delay(this@MainActivity).toString())
        }
        AlertDialog.Builder(this).setTitle("Seconds to wait between prompts").setView(e)
            .setPositiveButton("Save") { _, _ ->
                val v = e.text.toString().toIntOrNull() ?: 60
                Prefs.setDelay(this, v.coerceIn(5, 3600))
            }.setNegativeButton("Cancel", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
