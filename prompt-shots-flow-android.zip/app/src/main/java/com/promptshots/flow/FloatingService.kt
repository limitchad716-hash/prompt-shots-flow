package com.promptshots.flow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var edit: EditText? = null
    private var info: TextView? = null
    private var index = 0
    private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (bubble == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            addBubble()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        }
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("flow", "Floating window", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "flow") else Notification.Builder(this)
        val n = b.setContentTitle("FLOW floating window is on")
            .setContentText("Tap to open Prompt Shots")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun addBubble() {
        val t = TextView(this).apply {
            text = "FLOW"; textSize = 11f; gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF2A1C00.toInt())
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFE8A317.toInt()) }
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12); lp.y = dp(160)
        t.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        lp.x = sx + dx; lp.y = sy + dy
                        wm.updateViewLayout(v, lp)
                        panel?.let { p -> (p.layoutParams as? WindowManager.LayoutParams)?.let { pl ->
                            pl.x = lp.x; pl.y = lp.y + dp(62); wm.updateViewLayout(p, pl) } }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel()
                }
                return true
            }
        })
        wm.addView(t, lp)
        bubble = t; bubbleLp = lp
    }

    private fun togglePanel() {
        val old = panel
        if (old != null) { list(); wm.removeView(old); panel = null; return }
        val p = buildPanel()
        val bl = bubbleLp
        val lp = WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = bl?.x ?: dp(12); lp.y = (bl?.y ?: dp(160)) + dp(62)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        wm.addView(p, lp)
        panel = p
        refresh()
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; minHeight = 0; minimumHeight = 0
        setPadding(dp(6), dp(8), dp(6), dp(8))
        setOnClickListener { onClick() }
    }

    private fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        v.forEach { r.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        return r
    }

    private fun buildPanel(): LinearLayout {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply { setColor(0xF2151A24.toInt()); cornerRadius = dp(14).toFloat() }
        }
        val title = TextView(this).apply {
            text = "FLOW  paste & run"; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFE8A317.toInt())
        }
        val e = EditText(this).apply {
            hint = "Prompts, one per line"
            setHintTextColor(0xFF8A93A3.toInt()); setTextColor(0xFFE9EDF3.toInt()); textSize = 13f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4; maxLines = 6; gravity = Gravity.TOP
            setText(Prefs.prompts(this@FloatingService))
        }
        edit = e
        val i = TextView(this).apply { setTextColor(0xFF9AA4B5.toInt()); textSize = 12f }
        info = i
        p.addView(title); p.addView(e); p.addView(i)
        p.addView(row(
            btn("Paste list") { pasteClipboard() },
            btn("Clear") { e.setText(""); index = 0; refresh() }
        ))
        p.addView(row(
            btn("<") { index = maxOf(0, index - 1); refresh() },
            btn("Run this") { runOne() },
            btn(">") { index++; refresh() }
        ))
        p.addView(row(
            btn("Run all") { runAll() },
            btn("Stop") { stopAll(); toast("Stopped") }
        ))
        p.addView(row(
            btn("Hide") { togglePanel() },
            btn("Close FLOW") { stopSelf() }
        ))
        return p
    }

    private fun list(): List<String> {
        val t = edit?.text?.toString() ?: ""
        Prefs.setPrompts(this, t)
        return t.lines().map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun refresh() {
        val l = list()
        if (index >= l.size) index = 0
        info?.text = if (l.isEmpty()) "No prompts yet" else "Next: ${index + 1} / ${l.size}"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun pasteClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrBlank()) { toast("Clipboard is empty. Copy your prompts in Prompt Shots first."); return }
        edit?.setText(t); index = 0; refresh()
    }

    private fun runOne() {
        val l = list()
        if (l.isEmpty()) { toast("Add prompts first"); return }
        if (index >= l.size) index = 0
        val svc = FlowAccessibilityService.instance
        if (svc == null) { toast("Turn on Accessibility in Prompt Shots > Settings"); return }
        svc.pasteAndRun(l[index]) { toast(it) }
        index++; refresh()
    }

    private fun runAll() {
        if (running) return
        running = true
        step()
    }

    private fun stopAll() { running = false; h.removeCallbacksAndMessages(null) }

    private fun step() {
        if (!running) return
        val l = list()
        val svc = FlowAccessibilityService.instance
        if (svc == null) { running = false; toast("Turn on Accessibility in Prompt Shots > Settings"); return }
        if (index >= l.size) { running = false; index = 0; toast("Done"); refresh(); return }
        svc.pasteAndRun(l[index]) { toast(it) }
        index++; refresh()
        h.postDelayed({ step() }, Prefs.delay(this) * 1000L)
    }
}
