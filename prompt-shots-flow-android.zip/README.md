# Prompt Shots + FLOW floating window
Build: upload this project to GitHub, open Actions > Build APK > Run workflow, then download the APK artifact.
